﻿Module modError

    Public Sub ShowError(message As String)
        MessageBox.Show(message, "Program Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

End Module
